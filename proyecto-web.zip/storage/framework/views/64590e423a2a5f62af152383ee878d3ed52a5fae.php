<?php $__env->startSection('content'); ?>
    <div class="login-content">
        <div class="form-content">
            <h2>Mi<span>Mascota.com</span></h2>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="">
                    <div class="">
                        <input 
                        id="email" 
                        type="email" 
                        class=" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        name="email"
                        value="<?php echo e(old('email')); ?>" 
                        required 
                        autocomplete="email" 
                        autofocus
                        placeholder="Email"
                        >
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="">

                    <div class="">
                        <input 
                        id="password" 
                        type="password" 
                        class=" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="password" 
                        required 
                        autocomplete="current-password" 
                        placeholder="Contraseña">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                

                <div class="mb-3">
                    <div class="">
                        <button type="submit" class="btn btn-primary d-block w-100">
                            <?php echo e(__('Iniciar Sesión')); ?>

                        </button>
                    </div>
                </div>

                <div class="mb-3">
                    <div class="">
                        <a 
                        href="<?php echo e(url('login/google')); ?>"
                        class="btn btn-danger d-block w-100"
                        >
                            <?php echo e(__('Google')); ?>

                        </a>
                    </div>
                </div>
            </form>
            ¿No tienes una cuenta todavía en MiMascota.com?
            <a href="<?php echo e(route('register')); ?>">Regístrate</a>
        </div>

        <div class="info-login">

            <div>
                <p class="title" >MiMascota.com </p>
                <p>una plataforma para la adopción de mascotas</p>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\6to SEMESTRE\WEB\proyecto-web\resources\views/auth/login.blade.php ENDPATH**/ ?>