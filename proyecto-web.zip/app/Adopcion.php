<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Adopcion extends Model
{
    //
}
