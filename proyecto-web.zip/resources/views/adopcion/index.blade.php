@extends('layouts.app')

@section('content')
<h1>Adopcion</h1>
    
@endsection
