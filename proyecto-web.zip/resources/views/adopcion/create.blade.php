@extends('layouts.app')

<h1>create</h1>